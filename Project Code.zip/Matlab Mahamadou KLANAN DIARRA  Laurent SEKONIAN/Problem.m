function [fvalue,Contvalue] = Problem(fun,Cont,x)
fvalue = fun(x);
Contvalue = Cont(x);
end

