function [C] = fcont_MHW4D(X)
C = [X(1) + X(2)^2 + X(3)^3 - 3*sqrt(2) - 2 , X(2) - X(3)^2 + X(4) - 2*sqrt(2) + 2 , X(1)*X(5) - 2];
end