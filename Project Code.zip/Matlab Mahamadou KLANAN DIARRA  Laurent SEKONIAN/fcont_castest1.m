function [C] = fcont_castest1(X)
C = X(1)+X(2)-1;
end

