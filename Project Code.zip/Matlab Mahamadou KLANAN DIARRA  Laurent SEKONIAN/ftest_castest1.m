function [f] = ftest_castest1(X)
f = X(1)^2+X(2)^2
end
